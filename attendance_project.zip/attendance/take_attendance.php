<?php
$file = __DIR__ . '/students.json';
$students = [];
if (file_exists($file)) {
    $json = file_get_contents($file);
    $data = json_decode($json, true);
    if (is_array($data)) {
        $students = $data;
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    ?>
    <!doctype html>
    <html lang="en">
    <head>
      <meta charset="utf-8">
      <title>Take Attendance</title>
      <link rel="stylesheet" href="style.css">
    </head>
    <body>
      <div class="container">
        <h1>Take Attendance</h1>
        <?php if (empty($students)): ?>
          <div class="notice">No students found. First add students via <a href="add_student.html">Add Student</a>.</div>
        <?php else: ?>
          <form method="post" id="attendanceForm">
            <table class="table" role="table">
              <thead>
                <tr><th>Student ID</th><th>Name</th><th>Group</th><th>Status</th></tr>
              </thead>
              <tbody>
              <?php foreach ($students as $s): 
                $sid = htmlspecialchars($s['student_id']);
                $name = htmlspecialchars($s['name']);
                $group = htmlspecialchars($s['group']);
              ?>
                <tr>
                  <td><?php echo $sid; ?></td>
                  <td><?php echo $name; ?></td>
                  <td><?php echo $group; ?></td>
                  <td>
                    <label><input type="radio" name="status_<?php echo $sid; ?>" value="present" checked> Present</label>
                    <label><input type="radio" name="status_<?php echo $sid; ?>" value="absent"> Absent</label>
                  </td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
            <button type="submit">Save Attendance for Today</button>
          </form>
        <?php endif; ?>
        <a href="add_student.html">Add Student</a>
      </div>
    </body>
    </html>
    <?php
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($students)) {
        echo "No students to take attendance for.";
        exit;
    }
    $today = date('Y-m-d');
    $outFile = __DIR__ . "/attendance_{$today}.json";
    if (file_exists($outFile)) {
        echo "<!doctype html><html><head><meta charset='utf-8'><title>Already Taken</title>";
        echo "<link rel='stylesheet' href='style.css'></head><body><div class='container'>";
        echo "<h1>Attendance already taken</h1>";
        echo "<div class='notice'>Attendance for {$today} has already been taken.</div>";
        echo "<a href='take_attendance.php'>Back</a></div></body></html>";
        exit;
    }
    $attendance = [];
    foreach ($students as $s) {
        $sid = $s['student_id'];
        $field = 'status_' . $sid;
        $status = isset($_POST[$field]) && $_POST[$field] === 'present' ? 'present' : 'absent';
        $attendance[] = ['student_id' => $sid, 'status' => $status];
    }
    $saved = file_put_contents($outFile, json_encode($attendance, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
    echo "<!doctype html><html><head><meta charset='utf-8'><title>Saved</title>";
    echo "<link rel='stylesheet' href='style.css'></head><body><div class='container'>";
    echo "<h1>Attendance Saved</h1>";
    echo "<div class='notice'>Attendance for <strong>{$today}</strong> saved.</div>";
    echo "<a href='take_attendance.php'>Back</a></div></body></html>";
    exit;
}