<?php
function send_error($msg) {
    echo "<!doctype html><html><head><meta charset='utf-8'><title>Error</title>";
    echo "<link rel='stylesheet' href='style.css'></head><body><div class='container'>";
    echo "<h1>Error</h1><div class='error'>".htmlspecialchars($msg)."</div>";
    echo "<a href='add_student.html'>Back to Add Student</a></div></body></html>";
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: add_student.html');
    exit;
}
$student_id = isset($_POST['student_id']) ? trim($_POST['student_id']) : '';
$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$group = isset($_POST['group']) ? trim($_POST['group']) : '';
if ($student_id === '' || $name === '' || $group === '') {
    send_error('All fields are required.');
}
if (!preg_match('/^[\w\-]+$/', $student_id)) {
    send_error('Student ID must be alphanumeric (letters, numbers, -, _).');
}
$newStudent = [
    'student_id' => $student_id,
    'name' => $name,
    'group' => $group
];
$file = __DIR__ . '/students.json';
$students = [];
if (file_exists($file)) {
    $json = file_get_contents($file);
    $data = json_decode($json, true);
    if (is_array($data)) {
        $students = $data;
    }
}
foreach ($students as $s) {
    if (isset($s['student_id']) && $s['student_id'] === $student_id) {
        send_error('A student with this ID already exists.');
    }
}
$students[] = $newStudent;
$saved = file_put_contents($file, json_encode($students, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
if ($saved === false) {
    send_error('Failed to save student. Check file permissions.');
}
echo "<!doctype html><html><head><meta charset='utf-8'><title>Added</title>";
echo "<link rel='stylesheet' href='style.css'></head><body><div class='container'>";
echo "<h1>Student Added</h1>";
echo "<div class='notice'>Student <strong>" . htmlspecialchars($name) . " (" . htmlspecialchars($student_id) . ")</strong> was added successfully.</div>";
echo "<a href='add_student.html'>Add another student</a> &nbsp; | &nbsp; <a href='take_attendance.php'>Go to Take Attendance</a>";
echo "</div></body></html>";